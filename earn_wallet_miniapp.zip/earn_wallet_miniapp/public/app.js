(function () {
  "use strict";

  const TG = window.Telegram && window.Telegram.WebApp ? window.Telegram.WebApp : null;
  const API_BASE = (document.querySelector('meta[name="api-base"]') || {}).content || "";
  const MIN_WITHDRAW = 20000; // poisha (BDT 200.00)
  const MIN_TRANSFER = 100;   // poisha (BDT 1.00)

  const state = { data: null, initData: "", stack: ["home"], pending: null, lastBalance: 0 };
  const $ = (id) => document.getElementById(id);
  const screens = () => document.querySelectorAll(".screen");

  /* ---------- helpers ---------- */
  function fmt(p) {
    const n = Number(p || 0) / 100;
    return "BDT " + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  function toPoisha(text) {
    const s = String(text || "").replace(/BDT|,|\s/gi, "");
    if (!/^\d+(\.\d{1,2})?$/.test(s)) return null;
    const v = Math.round(parseFloat(s) * 100);
    return v > 0 ? v : null;
  }
  function haptic(kind) {
    try {
      if (!TG || !TG.HapticFeedback) return;
      if (kind === "success" || kind === "error" || kind === "warning") TG.HapticFeedback.notificationOccurred(kind);
      else TG.HapticFeedback.impactOccurred(kind || "light");
    } catch (_) {}
  }
  function toast(msg, cls) {
    const t = $("toast");
    t.textContent = msg;
    t.className = "toast show " + (cls || "");
    clearTimeout(toast._t);
    toast._t = setTimeout(() => (t.className = "toast " + (cls || "")), 2600);
  }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }
  async function api(path, opts) {
    const o = Object.assign({ method: "GET", headers: {} }, opts || {});
    o.headers["X-Init-Data"] = state.initData;
    if (o.body && typeof o.body !== "string") {
      o.headers["Content-Type"] = "application/json";
      o.body = JSON.stringify(o.body);
    }
    const res = await fetch(API_BASE + path, o);
    let json = null;
    try { json = await res.json(); } catch (_) {}
    if (!res.ok) {
      const msg = (json && (json.message || json.detail)) || "Something went wrong. Try again.";
      const err = new Error(msg);
      err.status = res.status;
      err.payload = json;
      throw err;
    }
    return json;
  }

  /* ---------- count-up animation ---------- */
  function animateBalance(to) {
    const el = $("balance");
    const from = state.lastBalance || 0;
    state.lastBalance = to;
    const start = performance.now();
    const dur = 900;
    function step(now) {
      const t = Math.min(1, (now - start) / dur);
      const eased = 1 - Math.pow(1 - t, 3);
      const v = Math.round(from + (to - from) * eased);
      el.textContent = fmt(v);
      if (t < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  /* ---------- rendering ---------- */
  function txRow(t, i) {
    const pos = t.amount >= 0;
    const icon = { sent: "↗", received: "↙", withdrawal: "🏧", bonus: "★", promo: "🎟", cashback: "💎" }[t.kind] || "•";
    const sign = pos ? "+" : "−";
    const amt = fmt(Math.abs(t.amount));
    const clickable = t.receipt;
    return `<div class="tx" data-ref="${esc(t.ref)}" data-receipt="${clickable ? 1 : 0}" style="animation-delay:${i * 40}ms">
      <div class="ico">${icon}</div>
      <div class="main">
        <div class="t">${esc(t.title)}</div>
        <div class="d">${esc(t.detail)} · ${esc(t.created)}</div>
        ${clickable ? '<div class="rc">View receipt →</div>' : ""}
      </div>
      <div class="amt ${pos ? "pos" : "neg"}">${sign}${amt}</div>
    </div>`;
  }
  function renderLists(txs) {
    const list = txs || [];
    const recent = list.slice(0, 5);
    $("recentList").innerHTML = recent.length ? recent.map(txRow).join("") : '<div class="empty">No transactions yet. Your first earnings will show here.</div>';
    $("txList").innerHTML = list.length ? list.map(txRow).join("") : '<div class="empty">No transactions yet.</div>';
  }
  function renderState(d) {
    state.data = d;
    const name = (d.user && d.user.first_name) || "Friend";
    const initial = (name[0] || "?").toUpperCase();
    $("avatar").textContent = initial;
    $("drawerAvatar").textContent = initial;
    $("drawerName").textContent = name;
    $("drawerUid").textContent = d.public_uid;
    $("publicUid").textContent = d.public_uid;
    $("referLink").textContent = d.referral_link || "Link unavailable right now";
    $("referBonus").textContent = fmt(d.referral_bonus);
    $("refCount").textContent = d.referral_count;
    $("refEarned").textContent = fmt(d.referral_earned);
    $("supportBtn").href = d.bot_username ? "https://t.me/" + d.bot_username : "#";
    animateBalance(d.balance);
    const b = d.bonus || {};
    $("bonusStreak").textContent = b.streak || 0;
    $("bonusBtn").disabled = !b.claimable;
    $("bonusOrb").classList.toggle("idle", !b.claimable);
    $("bonusText").textContent = b.claimable
      ? "Your bonus is ready. Tap claim to add it to your balance."
      : "Come back in " + (b.wait_text || "a while") + " to claim again.";
    renderLists(d.transactions);
  }
  async function loadState() {
    try {
      const d = await api("/api/state");
      renderState(d);
    } catch (e) {
      toast(e.message, "bad");
      haptic("error");
    }
  }

  /* ---------- navigation ---------- */
  const TITLES = {
    home: "Earn Wallet", send: "Send", send_confirm: "Confirm transfer", withdraw: "Withdraw",
    withdraw_confirm: "Confirm withdrawal", transactions: "Transactions", receipt: "Receipt",
    refer: "Refer & Earn", bonus: "Daily Bonus", promo: "Promo Code", cashback: "Cashback Offers", support: "Support"
  };
  const MENU_SCREEN = { home: "home", send: "send", withdraw: "withdraw", transactions: "transactions", refer: "refer", bonus: "bonus", promo: "promo", cashback: "cashback", support: "support" };

  function show(name, push) {
    const current = state.stack[state.stack.length - 1];
    if (name === current) return;
    if (push !== false && name !== "home") {
      state.stack.push(name);
    } else if (push === false) {
      state.stack = [name];
    }
    if (name === "home") state.stack = ["home"];
    screens().forEach((s) => s.classList.toggle("active", s.dataset.screen === name));
    $("topTitle").textContent = TITLES[name] || "Earn Wallet";
    document.querySelectorAll(".menu button").forEach((b) => b.classList.toggle("active", b.dataset.go === MENU_SCREEN[name]));
    window.scrollTo({ top: 0, behavior: "smooth" });
    updateChrome();
    if (name === "cashback") loadCashback();
    if (name === "bonus") renderBonusScreen();
    if (name === "refer") loadState();
  }
  function goBack() {
    if (state.stack.length > 1) {
      state.stack.pop();
      const prev = state.stack.pop();
      show(prev, true);
    }
  }
  function updateChrome() {
    const atHome = state.stack.length <= 1;
    if (TG && TG.BackButton) {
      if (atHome) TG.BackButton.hide(); else TG.BackButton.show();
    }
    // hamburger stays visible; back is handled by Telegram BackButton
  }
  function openDrawer(open) {
    $("drawer").classList.toggle("open", open);
    $("scrim").classList.toggle("show", open);
    haptic("light");
  }

  /* ---------- MainButton helper ---------- */
  let mainHandler = null;
  function setMain(text, handler, enabled) {
    if (!TG || !TG.MainButton) return;
    if (mainHandler) TG.MainButton.offClick(mainHandler);
    mainHandler = handler;
    TG.MainButton.setText(text);
    if (enabled === false) TG.MainButton.disable(); else TG.MainButton.enable();
    TG.MainButton.show();
    if (handler) TG.MainButton.onClick(handler);
  }
  function clearMain() {
    if (!TG || !TG.MainButton) return;
    if (mainHandler) TG.MainButton.offClick(mainHandler);
    mainHandler = null;
    TG.MainButton.hide();
  }

  /* ---------- send flow ---------- */
  function sendFlow() {
    const to = $("sendTo").value.trim();
    const p = toPoisha($("sendAmt").value);
    $("sendErr").textContent = "";
    if (!to) return ($("sendErr").textContent = "Enter a recipient ID."), haptic("error");
    if (!p) return ($("sendErr").textContent = "Enter a valid amount, for example 25 or 25.50."), haptic("error");
    if (p < MIN_TRANSFER) return ($("sendErr").textContent = "The minimum transfer is BDT 1.00."), haptic("error");
    if (state.data && p > state.data.balance) return ($("sendErr").textContent = "Not enough balance."), haptic("error");
    state.pending = { type: "send", recipient: to, amount: p };
    $("cSendAmt").textContent = fmt(p);
    $("cSendTo").textContent = to;
    show("send_confirm");
    setMain("CONFIRM SEND " + fmt(p), confirmSend, true);
    haptic("medium");
  }
  async function confirmSend() {
    if (!state.pending || state.pending.type !== "send") return;
    const amount = (state.pending.amount / 100).toFixed(2);
    if (TG && TG.MainButton) TG.MainButton.showProgress(false);
    try {
      const r = await api("/api/send", { method: "POST", body: { recipient: state.pending.recipient, amount } });
      haptic("success");
      toast(r.message, "good");
      state.pending = null;
      $("sendTo").value = ""; $("sendAmt").value = "";
      clearMain();
      await loadState();
      show("transactions");
    } catch (e) {
      haptic("error");
      toast(e.message, "bad");
    }
  }

  /* ---------- withdraw flow ---------- */
  function withdrawFlow() {
    const num = $("wdNum").value.replace(/[\s-]/g, "");
    const p = toPoisha($("wdAmt").value);
    $("wdErr").textContent = "";
    if (!/^01\d{9}$/.test(num)) return ($("wdErr").textContent = "bKash number must be 11 digits and start with 01."), haptic("error");
    if (!p) return ($("wdErr").textContent = "Enter a valid amount."), haptic("error");
    if (p < MIN_WITHDRAW) return ($("wdErr").textContent = "The minimum withdrawal is BDT 200.00."), haptic("error");
    if (state.data && p > state.data.balance) return ($("wdErr").textContent = "Not enough balance."), haptic("error");
    state.pending = { type: "withdraw", bkash: num, amount: p };
    $("cWdAmt").textContent = fmt(p);
    $("cWdNum").textContent = num;
    show("withdraw_confirm");
    setMain("CONFIRM WITHDRAWAL " + fmt(p), confirmWithdraw, true);
    haptic("medium");
  }
  async function confirmWithdraw() {
    if (!state.pending || state.pending.type !== "withdraw") return;
    try {
      const r = await api("/api/withdraw", { method: "POST", body: { bkash: state.pending.bkash, amount: (state.pending.amount / 100).toFixed(2) } });
      haptic("success");
      toast(r.message, "good");
      state.pending = null;
      $("wdNum").value = ""; $("wdAmt").value = "";
      clearMain();
      await loadState();
      show("transactions");
    } catch (e) {
      haptic("error");
      toast(e.message, "bad");
    }
  }

  /* ---------- receipts (image needs the auth header, so fetch as blob) ---------- */
  let lastBlobUrl = null;
  async function openReceipt(ref) {
    show("receipt");
    $("rcTitle").textContent = "Receipt " + ref;
    $("rcImg").style.display = "none";
    $("rcErr").textContent = "";
    $("rcLoading").style.display = "block";
    try {
      const res = await fetch(API_BASE + "/api/receipt/" + encodeURIComponent(ref), { headers: { "X-Init-Data": state.initData } });
      if (!res.ok) {
        let msg = "Receipt not available.";
        try { msg = (await res.json()).detail || msg; } catch (_) {}
        throw new Error(msg);
      }
      const blob = await res.blob();
      if (lastBlobUrl) URL.revokeObjectURL(lastBlobUrl);
      lastBlobUrl = URL.createObjectURL(blob);
      $("rcImg").src = lastBlobUrl;
      $("rcImg").style.display = "block";
      $("rcLoading").style.display = "none";
    } catch (e) {
      $("rcLoading").style.display = "none";
      $("rcErr").textContent = e.message;
    }
  }

  /* ---------- bonus ---------- */
  function renderBonusScreen() {
    if (state.data) renderState(state.data);
  }
  async function claimBonus() {
    $("bonusBtn").disabled = true;
    try {
      const r = await api("/api/bonus", { method: "POST" });
      haptic("success");
      toast(r.message, "good");
      await loadState();
    } catch (e) {
      haptic("error");
      toast(e.message, "bad");
      await loadState();
    }
  }

  /* ---------- promo ---------- */
  async function claimPromo() {
    const code = $("promoCode").value.trim();
    $("promoErr").textContent = ""; $("promoOk").textContent = "";
    if (!code) return ($("promoErr").textContent = "Enter a promo code."), haptic("error");
    try {
      const r = await api("/api/promo", { method: "POST", body: { code } });
      haptic("success");
      $("promoOk").textContent = r.message;
      $("promoCode").value = "";
      toast(r.message, "good");
      await loadState();
    } catch (e) {
      haptic("error");
      $("promoErr").textContent = e.message;
    }
  }

  /* ---------- cashback ---------- */
  async function loadCashback() {
    try {
      const r = await api("/api/cashback");
      $("cbList").innerHTML = r.offers.map((o) => {
        const pct = o.complete ? 100 : Math.min(100, Math.round(((parseProgress(o.progress)) || 0) * 100));
        const btn = o.claimed_code
          ? `<div class="stat-line" style="margin-top:10px">Claimed · code <b>${esc(o.claimed_code)}</b></div>`
          : `<button class="btn primary" data-claim="${o.id}" ${o.complete ? "" : "disabled"}>${o.complete ? "Claim " + fmt(o.reward) : "Not yet"}</button>`;
        return `<div class="glass cb">
          <div class="top"><b>${esc(o.title)}</b><span class="reward">+${fmt(o.reward)}</span></div>
          <div class="small">${esc(o.need)}</div>
          <div class="bar"><i style="width:${pct}%"></i></div>
          <div class="small">${esc(o.progress)}</div>
          ${btn}
        </div>`;
      }).join("");
    } catch (e) {
      $("cbList").innerHTML = `<div class="empty">${esc(e.message)}</div>`;
    }
  }
  function parseProgress(s) {
    const m = String(s || "").match(/(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)/);
    if (!m) return 0;
    return Math.min(1, parseFloat(m[1]) / parseFloat(m[2]));
  }
  async function claimCashback(id) {
    try {
      const r = await api("/api/cashback/claim", { method: "POST", body: { offer_id: Number(id) } });
      if (r.ok) { haptic("success"); toast(r.message, "good"); } else { haptic("warning"); toast(r.message, "bad"); }
      await loadCashback();
      await loadState();
    } catch (e) {
      haptic("error");
      toast(e.message, "bad");
    }
  }

  /* ---------- wiring ---------- */
  function wire() {
    $("menuBtn").addEventListener("click", () => openDrawer(true));
    $("scrim").addEventListener("click", () => openDrawer(false));
    document.querySelectorAll("[data-go]").forEach((el) => {
      el.addEventListener("click", () => {
        const target = el.dataset.go;
        openDrawer(false);
        haptic("light");
        if (target === "home") { state.stack = ["home"]; show("home", false); }
        else { state.stack = ["home"]; show(target, true); }
        if (target === "send") clearMain();
        if (target === "withdraw") clearMain();
      });
    });
    $("copyUidBtn").addEventListener("click", () => copy(state.data && state.data.public_uid, "ID copied"));
    $("copyRefBtn").addEventListener("click", () => copy(state.data && state.data.referral_link, "Referral link copied"));
    $("bonusBtn").addEventListener("click", claimBonus);
    $("promoCode").addEventListener("keydown", (e) => { if (e.key === "Enter") claimPromo(); });
    $("txList").addEventListener("click", onTxClick);
    $("recentList").addEventListener("click", onTxClick);
    $("cbList").addEventListener("click", (e) => {
      const b = e.target.closest("[data-claim]");
      if (b) claimCashback(b.dataset.claim);
    });
    // primary actions on the form screens: MainButton shows on the form, sends to confirm screen
    ["sendTo", "sendAmt"].forEach((id) => $(id).addEventListener("keydown", (e) => { if (e.key === "Enter") sendFlow(); }));
    ["wdNum", "wdAmt"].forEach((id) => $(id).addEventListener("keydown", (e) => { if (e.key === "Enter") withdrawFlow(); }));
    if (TG && TG.onEvent) TG.onEvent("backButtonClicked", goBack);
  }
  function onTxClick(e) {
    const row = e.target.closest(".tx");
    if (!row) return;
    if (row.dataset.receipt !== "1") { haptic("light"); toast("No receipt for this item.", "bad"); return; }
    haptic("light");
    openReceipt(row.dataset.ref);
  }
  function copy(text, okMsg) {
    if (!text) return toast("Nothing to copy yet", "bad");
    const done = () => { haptic("success"); toast(okMsg, "good"); };
    if (navigator.clipboard) navigator.clipboard.writeText(text).then(done, () => fallbackCopy(text, done));
    else fallbackCopy(text, done);
  }
  function fallbackCopy(text, done) {
    const ta = document.createElement("textarea");
    ta.value = text; document.body.appendChild(ta); ta.select();
    try { document.execCommand("copy"); done(); } catch (_) { toast("Copy failed", "bad"); }
    ta.remove();
  }

  /* MainButton is active on the form screens (Send/Withdraw) as "Review"; confirm screens use the handlers set in the flows. */
  function formMainButton() {
    const cur = state.stack[state.stack.length - 1];
    if (cur === "send") setMain("REVIEW TRANSFER", sendFlow, true);
    else if (cur === "withdraw") setMain("REVIEW WITHDRAWAL", withdrawFlow, true);
    else clearMain();
  }

  function applyTelegramTheme() {
    if (!TG) return;
    try {
      const tp = TG.themeParams || {};
      if (tp.secondary_bg_color) document.documentElement.style.setProperty("--glass", "rgba(255,255,255,.06)");
      if (TG.setHeaderColor) TG.setHeaderColor("#0b0a1f");
      if (TG.setBackgroundColor) TG.setBackgroundColor("#0b0a1f");
      if (TG.setBottomBarColor) TG.setBottomBarColor("#0b0a1f");
    } catch (_) {}
  }

  async function boot() {
    wire();
    if (TG) {
      TG.ready();
      TG.expand();
      applyTelegramTheme();
      if (TG.BackButton) TG.BackButton.onClick(goBack);
      state.initData = TG.initData || "";
    }
    if (!state.initData) {
      $("drawerName").textContent = "Open from Telegram";
      toast("Open this app from the bot's menu button in Telegram.", "bad");
      return;
    }
    try {
      const auth = await api("/api/auth", { method: "POST" });
      renderState(auth);
    } catch (e) {
      toast(e.message, "bad");
      haptic("error");
      return;
    }
    // Refresh the form MainButton whenever the visible screen changes.
    window.__formMain = formMainButton;
    formMainButton();
    setInterval(() => { if (!document.hidden) loadState(); }, 20000);
  }

  // Keep MainButton in sync with the visible form screen.
  const _show = show;
  show = function (name, push) { _show(name, push); if (window.__formMain) window.__formMain(); };

  document.addEventListener("DOMContentLoaded", boot);
})();
